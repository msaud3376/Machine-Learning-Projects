
import streamlit as st
import numpy as np
import torch
import torch.nn as nn
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")
import warnings
warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="Hardware Mind — Bottleneck Calculator",
    page_icon="🖥️",
    layout="wide",
    initial_sidebar_state="expanded",
)

SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)

FEATURE_COLS = [
    "cpu_cores", "cpu_threads", "cpu_base_clock", "cpu_boost_clock",
    "cpu_tdp", "ram_gb", "ram_speed_mhz", "gpu_vram_gb", "gpu_tflops",
    "gpu_tdp", "psu_wattage", "pcie_version", "socket_match", "ddr_gen_match",
]

COMPAT_LABELS = {
    0: ("❌ Incompatible", "#ff4b4b"),
    1: ("⚠️ Partial",      "#ffa500"),
    2: ("✅ Compatible",   "#21c354"),
}

RESOLUTIONS = [
    {"label": "1920 × 1080",  "fps_scale": 1.000, "gpu_load": 1.00, "name": "FHD"},
    {"label": "2560 × 1440",  "fps_scale": 0.640, "gpu_load": 1.42, "name": "QHD"},
    {"label": "3840 × 1600",  "fps_scale": 0.460, "gpu_load": 1.97, "name": "UW4K"},
    {"label": "3840 × 2160",  "fps_scale": 0.365, "gpu_load": 2.55, "name": "4K"},
]

GAMES = [
    {"name": "Counter-Strike 2",        "base_fps": 283, "cpu_w": 0.65, "icon": "🔫"},
    {"name": "Valorant",                "base_fps": 370, "cpu_w": 0.70, "icon": "🎯"},
    {"name": "Minecraft: Java Edition", "base_fps": 326, "cpu_w": 0.62, "icon": "⛏️"},
    {"name": "Fortnite",                "base_fps": 154, "cpu_w": 0.38, "icon": "🏝️"},
    {"name": "Call of Duty: Warzone",   "base_fps": 135, "cpu_w": 0.32, "icon": "💣"},
    {"name": "PUBG: Battlegrounds",     "base_fps": 162, "cpu_w": 0.33, "icon": "🪂"},
    {"name": "Grand Theft Auto V",      "base_fps": 133, "cpu_w": 0.38, "icon": "🚗"},
    {"name": "Rust",                    "base_fps":  98, "cpu_w": 0.50, "icon": "🏚️"},
    {"name": "Cyberpunk 2077",          "base_fps":  69, "cpu_w": 0.14, "icon": "🌆"},
    {"name": "Red Dead Redemption 2",   "base_fps":  73, "cpu_w": 0.18, "icon": "🤠"},
]

PRESETS = {
    "🎮 Gaming PC (High-End)": {
        "desc": "Powerful rig aimed at 1440p / 4K gaming with a flagship GPU.",
        "cpu_name": "Intel Core i9-14900K", "gpu_name": "GeForce RTX 4090",
        "cpu_cores": 16, "cpu_threads": 32, "cpu_base_clock": 3.6,
        "cpu_boost_clock": 5.2, "cpu_tdp": 125.0, "ram_gb": 32.0,
        "ram_speed_mhz": 6000.0, "gpu_vram_gb": 16.0, "gpu_tflops": 82.0,
        "gpu_tdp": 320.0, "psu_wattage": 1000.0, "pcie_version": 5.0,
        "socket_match": 1.0, "ddr_gen_match": 1.0,
    },
    "🎮 Gaming PC (Mid-Range)": {
        "desc": "Solid 1080p / 1440p build that balances price and performance.",
        "cpu_name": "Intel Core i7-9700K", "gpu_name": "GeForce RTX 4060",
        "cpu_cores": 8, "cpu_threads": 16, "cpu_base_clock": 3.4,
        "cpu_boost_clock": 4.9, "cpu_tdp": 95.0, "ram_gb": 16.0,
        "ram_speed_mhz": 3600.0, "gpu_vram_gb": 8.0, "gpu_tflops": 40.0,
        "gpu_tdp": 200.0, "psu_wattage": 650.0, "pcie_version": 4.0,
        "socket_match": 1.0, "ddr_gen_match": 1.0,
    },
    "💡 Budget Build": {
        "desc": "Entry-level PC for everyday tasks, light gaming, and school/work.",
        "cpu_name": "Intel Core i3-12100F", "gpu_name": "GeForce RTX 3060",
        "cpu_cores": 4, "cpu_threads": 8, "cpu_base_clock": 3.0,
        "cpu_boost_clock": 4.2, "cpu_tdp": 65.0, "ram_gb": 8.0,
        "ram_speed_mhz": 3200.0, "gpu_vram_gb": 4.0, "gpu_tflops": 10.0,
        "gpu_tdp": 100.0, "psu_wattage": 450.0, "pcie_version": 3.0,
        "socket_match": 1.0, "ddr_gen_match": 1.0,
    },
    "🖥️ Workstation / Content Creation": {
        "desc": "Heavy multi-threaded workloads: 3D rendering, video editing, ML.",
        "cpu_name": "AMD Ryzen 9 7950X", "gpu_name": "GeForce RTX 4090",
        "cpu_cores": 24, "cpu_threads": 48, "cpu_base_clock": 3.8,
        "cpu_boost_clock": 5.4, "cpu_tdp": 250.0, "ram_gb": 64.0,
        "ram_speed_mhz": 4800.0, "gpu_vram_gb": 24.0, "gpu_tflops": 70.0,
        "gpu_tdp": 350.0, "psu_wattage": 1200.0, "pcie_version": 5.0,
        "socket_match": 1.0, "ddr_gen_match": 1.0,
    },
    "⬆️ Upgrade GPU Only": {
        "desc": "Existing mid-tier CPU with a new high-end GPU — watch for bottleneck!",
        "cpu_name": "Intel Core i5-10400F", "gpu_name": "GeForce RTX 4080",
        "cpu_cores": 6, "cpu_threads": 12, "cpu_base_clock": 3.2,
        "cpu_boost_clock": 4.5, "cpu_tdp": 85.0, "ram_gb": 16.0,
        "ram_speed_mhz": 3200.0, "gpu_vram_gb": 16.0, "gpu_tflops": 90.0,
        "gpu_tdp": 400.0, "psu_wattage": 850.0, "pcie_version": 4.0,
        "socket_match": 1.0, "ddr_gen_match": 1.0,
    },
    "🧠 AI / ML Workstation": {
        "desc": "Training neural networks locally — max VRAM and TFLOPS matter.",
        "cpu_name": "AMD Ryzen 9 7900X", "gpu_name": "NVIDIA RTX 4090",
        "cpu_cores": 16, "cpu_threads": 32, "cpu_base_clock": 3.7,
        "cpu_boost_clock": 5.1, "cpu_tdp": 170.0, "ram_gb": 64.0,
        "ram_speed_mhz": 6000.0, "gpu_vram_gb": 24.0, "gpu_tflops": 100.0,
        "gpu_tdp": 450.0, "psu_wattage": 1200.0, "pcie_version": 5.0,
        "socket_match": 1.0, "ddr_gen_match": 1.0,
    },
    "🔧 Custom Build": {
        "desc": "Specify every component yourself for a fully custom analysis.",
        "cpu_name": "Custom CPU", "gpu_name": "Custom GPU",
        "cpu_cores": 8, "cpu_threads": 16, "cpu_base_clock": 3.4,
        "cpu_boost_clock": 4.8, "cpu_tdp": 105.0, "ram_gb": 16.0,
        "ram_speed_mhz": 3600.0, "gpu_vram_gb": 8.0, "gpu_tflops": 35.0,
        "gpu_tdp": 180.0, "psu_wattage": 750.0, "pcie_version": 4.0,
        "socket_match": 1.0, "ddr_gen_match": 1.0,
    },
}

class HardwareMindANN(nn.Module):
    def __init__(self, input_dim: int, num_classes: int = 3):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.BatchNorm1d(input_dim),
            nn.Linear(input_dim, 256), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(256, 128),       nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(128, 64),        nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(64, 32),         nn.ReLU(),
        )
        self.regression_head = nn.Sequential(
            nn.Linear(32, 16), nn.ReLU(), nn.Linear(16, 1)
        )
        self.classification_head = nn.Sequential(
            nn.Linear(32, 16), nn.ReLU(), nn.Linear(16, num_classes)
        )

    def forward(self, x):
        shared = self.backbone(x)
        return self.regression_head(shared), self.classification_head(shared)

_GPU_TFLOPS = {
    "RTX 4090": 82.6, "RTX 4080": 48.7, "RTX 4070": 29.1,
    "RTX 3060": 12.7, "GTX 1650": 4.0,
    "Radeon RX 7900 XTX": 61.4, "Radeon RX 7600": 21.8, "Radeon RX 6500 XT": 5.8,
}
_GPU_VRAM = {
    "RTX 4090": 24, "RTX 4080": 16, "RTX 4070": 12,
    "RTX 3060": 12, "GTX 1650": 4,
    "Radeon RX 7900 XTX": 24, "Radeon RX 7600": 8, "Radeon RX 6500 XT": 4,
}
_GPU_TDP = {
    "RTX 4090": 450, "RTX 4080": 320, "RTX 4070": 200,
    "RTX 3060": 170, "GTX 1650": 75,
    "Radeon RX 7900 XTX": 355, "Radeon RX 7600": 165, "Radeon RX 6500 XT": 107,
}
_CPU_BOOST = {
    "Intel Pentium Gold G7400": 3.7, "AMD Athlon 3000G": 3.5,
    "AMD Ryzen 9 7950X": 5.7,       "Intel Core i7-13700K": 5.4,
    "Intel Core i3-13100": 4.5,     "Intel Core i9-13900K": 5.8,
    "AMD Ryzen 5 5600X": 4.6,       "Intel Core i5-13600K": 5.1,
}
_CPU_BASE = {
    "Intel Pentium Gold G7400": 3.7, "AMD Athlon 3000G": 3.1,
    "AMD Ryzen 9 7950X": 4.5,       "Intel Core i7-13700K": 3.4,
    "Intel Core i3-13100": 3.4,     "Intel Core i9-13900K": 3.0,
    "AMD Ryzen 5 5600X": 3.7,       "Intel Core i5-13600K": 3.5,
}
_CPU_TDP = {
    "Intel Pentium Gold G7400": 46, "AMD Athlon 3000G": 35,
    "AMD Ryzen 9 7950X": 170,      "Intel Core i7-13700K": 125,
    "Intel Core i3-13100": 60,     "Intel Core i9-13900K": 125,
    "AMD Ryzen 5 5600X": 65,       "Intel Core i5-13600K": 125,
}

def _pcie_from_chipset(chipset: str) -> float:
    if any(c in str(chipset) for c in ("X670", "Z790", "B650")):
        return 5.0
    if any(c in str(chipset) for c in ("X570", "B660", "H670", "Z690", "B760", "H610")):
        return 4.0
    return 3.0

def load_real_dataset(csv_path: str = "Pc_build_data.csv") -> pd.DataFrame:
    df = pd.read_csv(csv_path)

    df["gpu_tflops"]      = df["GPU_Model"].map(_GPU_TFLOPS)
    df["gpu_vram_gb"]     = df["GPU_Model"].map(_GPU_VRAM)
    df["gpu_tdp"]         = df["GPU_Model"].map(_GPU_TDP)
    df["cpu_boost_clock"] = df["CPU_Model"].map(_CPU_BOOST)
    df["cpu_base_clock"]  = df["CPU_Model"].map(_CPU_BASE)
    df["cpu_tdp"]         = df["CPU_Model"].map(_CPU_TDP)
    df["pcie_version"]    = df["Motherboard_Chipset"].apply(_pcie_from_chipset)
    df["socket_match"]    = 1.0
    df["ddr_gen_match"]   = df["RAM_Type"].apply(
        lambda x: 1.0 if str(x) in ("DDR4", "DDR5") else 0.0
    )

    df.rename(columns={
        "CPU_Cores":    "cpu_cores",
        "CPU_Threads":  "cpu_threads",
        "RAM_Size_GB":  "ram_gb",
        "RAM_Speed_MHz": "ram_speed_mhz",
        "PSU_Wattage":  "psu_wattage",
    }, inplace=True)

    cpu_score = df["cpu_cores"] * df["cpu_boost_clock"] * 1.5
    gpu_score = df["gpu_tflops"] * 10
    df["bottleneck_pct"] = np.clip(
        np.abs(cpu_score - gpu_score) / (gpu_score + 1e-6) * 100, 0, 95
    )

    total_power  = df["cpu_tdp"] + df["gpu_tdp"] + 100
    power_ok     = (df["psu_wattage"] >= total_power).astype(int)
    pcie_ok      = (df["pcie_version"] >= 4).astype(int)
    compat_score = (
        df["socket_match"] * 40 + df["ddr_gen_match"] * 20 +
        power_ok * 30 + pcie_ok * 10
    )
    df["compatibility"] = np.where(compat_score >= 70, 2,
                          np.where(compat_score >= 40, 1, 0))

    keep = FEATURE_COLS + ["bottleneck_pct", "compatibility"]
    return df[keep].dropna().reset_index(drop=True)

_MODEL_CACHE_PATH = "hardware_mind_model.pt"

@st.cache_resource(show_spinner="🧠 Loading ANN model…")
def train_model():
    import os
    if os.path.exists(_MODEL_CACHE_PATH):
        try:
            checkpoint = torch.load(_MODEL_CACHE_PATH, map_location="cpu", weights_only=False)
            model = HardwareMindANN(input_dim=len(FEATURE_COLS))
            model.load_state_dict(checkpoint["model_state"])
            model.eval()
            scaler = checkpoint["scaler"]
            return model, scaler
        except Exception:
            pass

    csv_path = os.path.join(os.path.dirname(__file__), "Pc_build_data.csv")
    if not os.path.exists(csv_path):
        csv_path = "Pc_build_data.csv"
    df = load_real_dataset(csv_path)
    X  = df[FEATURE_COLS].values
    y_reg = df["bottleneck_pct"].values.astype(np.float32)
    y_clf = df["compatibility"].values.astype(np.int64)

    X_tmp, X_test, yr_tmp, yr_test, yc_tmp, yc_test = train_test_split(
        X, y_reg, y_clf, test_size=0.10, random_state=SEED, stratify=y_clf)
    X_train, X_val, yr_train, yr_val, yc_train, yc_val = train_test_split(
        X_tmp, yr_tmp, yc_tmp, test_size=0.111, random_state=SEED, stratify=yc_tmp)

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)

    device = torch.device("cpu")
    model  = HardwareMindANN(input_dim=len(FEATURE_COLS)).to(device)
    opt    = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    sched  = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=60)
    reg_c  = nn.MSELoss()
    clf_c  = nn.CrossEntropyLoss()

    Xt = torch.tensor(X_train, dtype=torch.float32)
    yr = torch.tensor(yr_train, dtype=torch.float32).unsqueeze(1)
    yc = torch.tensor(yc_train, dtype=torch.long)

    for _ in range(60):
        model.train()
        perm = torch.randperm(len(Xt))
        for i in range(0, len(Xt), 64):
            idx = perm[i:i+64]
            xb, yrb, ycb = Xt[idx], yr[idx], yc[idx]
            opt.zero_grad()
            rp, cp = model(xb)
            loss = 0.5 * reg_c(rp, yrb) + 0.5 * clf_c(cp, ycb)
            loss.backward()
            opt.step()
        sched.step()

    model.eval()

    try:
        torch.save({"model_state": model.state_dict(), "scaler": scaler}, _MODEL_CACHE_PATH)
    except Exception:
        pass

    return model, scaler

def predict(model, scaler, config):
    model.eval()
    x  = np.array([[config[f] for f in FEATURE_COLS]], dtype=np.float32)
    xs = scaler.transform(x)
    xt = torch.tensor(xs, dtype=torch.float32)
    with torch.no_grad():
        reg_out, clf_out = model(xt)
    bottleneck = float(reg_out.item())
    probs = torch.softmax(clf_out, dim=1).numpy().flatten()
    compat_idx = int(probs.argmax())
    return bottleneck, compat_idx, probs

def per_resolution_bottleneck(cpu_cores, cpu_boost, gpu_tflops):
    CPU_SCORE = cpu_cores * cpu_boost * 1.5
    GPU_BASE  = gpu_tflops * 10

    rows = []
    for r in RESOLUTIONS:
        eff_gpu = GPU_BASE / r["gpu_load"]
        if eff_gpu < CPU_SCORE:
            pct      = (CPU_SCORE - eff_gpu) / CPU_SCORE * 100
            limiting = "GPU"
        else:
            pct      = (eff_gpu - CPU_SCORE) / eff_gpu * 100
            limiting = "CPU"
        pct = round(min(pct, 95), 1)
        rows.append({"Resolution": r["label"], "Bottleneck": pct, "Limiting": limiting})
    return rows

def estimate_fps(cpu_cores, cpu_boost, gpu_tflops):
    GPU_REF_TFLOPS  = 40.0
    CPU_REF_SCORE   = 8 * 4.9
    gpu_factor      = gpu_tflops / GPU_REF_TFLOPS
    cpu_factor      = (cpu_cores * cpu_boost) / CPU_REF_SCORE

    result = {}
    for g in GAMES:
        w  = g["cpu_w"]
        cf = min(gpu_factor ** (1 - w) * cpu_factor ** w, 4.0)
        fps_1080 = g["base_fps"] * cf
        result[g["name"]] = {
            r["label"]: max(1, int(fps_1080 * r["fps_scale"]))
            for r in RESOLUTIONS
        }
    return result

def fps_percentages(cpu_cores, cpu_boost, gpu_tflops):
    all_fps = estimate_fps(cpu_cores, cpu_boost, gpu_tflops)
    thresholds = [30, 60, 90, 120, 144]
    rows = []
    for r in RESOLUTIONS:
        fps_vals = [all_fps[g["name"]][r["label"]] for g in GAMES]
        row = {"Resolution": r["label"]}
        for t in thresholds:
            frac = sum(1 for f in fps_vals if f >= t) / len(fps_vals) * 100
            row[f"{t}+ FPS"] = f"{round(frac)}%"
        rows.append(row)
    return rows

def recommended_ram(ram_gb):
    min_r = 16
    rec_r = 32
    adv_r = 64
    mx_r  = 128
    return min_r, rec_r, adv_r, mx_r

def upgrade_suggestions(ann_bottleneck, cpu_cores, cpu_boost, gpu_tflops):
    CPU_SCORE = cpu_cores * cpu_boost * 1.5
    GPU_SCORE = gpu_tflops * 10
    suggestions = []
    if GPU_SCORE < CPU_SCORE * 0.8:
        suggestions.append("🖼️ **Upgrade your GPU** — it is the primary bottleneck at higher resolutions.")
    if CPU_SCORE < GPU_SCORE * 0.6:
        suggestions.append("⚡ **Upgrade your CPU** — core count / boost clock is limiting GPU utilisation.")
    if ann_bottleneck > 40:
        suggestions.append("🔄 **Consider a balanced upgrade** — both components show high mismatch.")
    if not suggestions:
        suggestions.append("✅ **Your build is well-balanced.** No urgent upgrades needed.")
    return suggestions

def feature_importance_fig(model):
    weights    = model.backbone[1].weight.data.abs().mean(dim=0).numpy()
    importance = pd.Series(weights, index=FEATURE_COLS).sort_values()
    fig, ax    = plt.subplots(figsize=(7, 4), facecolor="#0e1117")
    ax.set_facecolor("#0e1117")
    colors = ["#4f8ef7" if v < importance.median() else "#7c3aed" for v in importance]
    importance.plot(kind="barh", ax=ax, color=colors)
    ax.set_xlabel("Mean |Weight| (first layer)", color="#aaa")
    ax.set_title("Feature Importance — ANN First Layer", fontsize=12,
                 fontweight="bold", color="#fff")
    ax.tick_params(colors="#aaa")
    ax.spines[["top", "right", "bottom", "left"]].set_visible(False)
    plt.tight_layout()
    return fig

def gauge_fig(value, label="Bottleneck"):
    fig, ax = plt.subplots(figsize=(3.5, 2.2), subplot_kw={"aspect": "equal"},
                           facecolor="#0e1117")
    ax.set_facecolor("#0e1117")
    ax.set_xlim(-1.2, 1.2)
    ax.set_ylim(-0.15, 1.25)
    ax.axis("off")
    theta = np.linspace(np.pi, 0, 200)
    ax.plot(np.cos(theta), np.sin(theta), color="#2a3050", linewidth=16,
            solid_capstyle="round")
    frac  = min(value / 95, 1.0)
    color = "#21c354" if frac < 0.35 else ("#ffa500" if frac < 0.65 else "#ff4b4b")
    theta_fill = np.linspace(np.pi, np.pi - frac * np.pi, 200)
    ax.plot(np.cos(theta_fill), np.sin(theta_fill), color=color, linewidth=16,
            solid_capstyle="round")
    ax.text(0, 0.22, f"{value:.1f}%", ha="center", va="center",
            fontsize=19, fontweight="bold", color=color)
    ax.text(0, -0.05, label, ha="center", va="center", fontsize=9, color="#888")
    plt.tight_layout(pad=0)
    return fig

st.markdown("""
<style>
/* ── Base ─────────────────────────────────────────── */
[data-testid="stAppViewContainer"] { background:#0e1117; }
[data-testid="stSidebar"]          { background:#131720; border-right:1px solid #1e2640; }
[data-testid="stSidebar"] h2       { color:#4f8ef7; }

/* ── Typography ───────────────────────────────────── */
.brand-logo {
    font-size:1.7rem; font-weight:900; color:#4f8ef7;
    letter-spacing:-1px; display:flex; align-items:center; gap:8px;
    margin-bottom:0;
}
.brand-sub {
    color:#888; font-size:0.88rem; margin:0 0 1.2rem 0;
}
.section-hdr {
    font-size:1rem; font-weight:700; color:#4f8ef7;
    border-bottom:2px solid #1e2640; padding-bottom:4px;
    margin:1rem 0 0.6rem 0;
}

/* ── Preset card ──────────────────────────────────── */
.preset-card {
    background:#141926; border-radius:10px; padding:0.9rem 1.1rem;
    border-left:4px solid #4f8ef7; margin-bottom:0.5rem;
}
.preset-card h4 { margin:0 0 0.2rem 0; color:#fff; font-size:0.98rem; }
.preset-card p  { margin:0; color:#aaa; font-size:0.82rem; }

/* ── Spec chips (CPU / GPU header) ───────────────── */
.spec-chip {
    display:inline-block; background:#1a2035; border-radius:8px;
    padding:0.55rem 1rem; margin:0.3rem 0.3rem 0.3rem 0;
    border:1px solid #2a3860;
}
.spec-chip .lbl { font-size:0.72rem; color:#888; text-transform:uppercase;
                   letter-spacing:0.5px; }
.spec-chip .val { font-size:1.0rem; font-weight:700; color:#e0e8ff; }

/* ── Result box ───────────────────────────────────── */
.result-box {
    background:#141926; border-radius:12px; padding:1rem 1.2rem;
    text-align:center; margin-bottom:0.7rem;
    border:1px solid #1e2640;
}
.result-label { color:#888; font-size:0.72rem; letter-spacing:1px;
                 text-transform:uppercase; }
.result-value { font-size:1.8rem; font-weight:800; margin-top:0.15rem; }

/* ── Data tables ──────────────────────────────────── */
.hw-table {
    width:100%; border-collapse:collapse; font-size:0.88rem;
    margin-bottom:0.8rem;
}
.hw-table th {
    background:#1a2035; color:#4f8ef7; padding:8px 12px;
    text-align:left; font-weight:600; font-size:0.78rem;
    text-transform:uppercase; letter-spacing:0.5px;
}
.hw-table td { padding:7px 12px; border-bottom:1px solid #1a2035; color:#dde; }
.hw-table tr:last-child td { border-bottom:none; }
.hw-table tr:hover td { background:#141926; }
.tag-none   { color:#21c354; font-weight:700; }
.tag-gpu    { color:#ffa500; font-weight:700; }
.tag-cpu    { color:#ff4b4b; font-weight:700; }

/* ── FPS badge ────────────────────────────────────── */
.fps-badge {
    display:inline-block; min-width:56px; text-align:center;
    border-radius:6px; padding:3px 6px; font-size:0.82rem; font-weight:700;
}
.fps-hi   { background:#1a3328; color:#21c354; }
.fps-ok   { background:#2a2a18; color:#d4c44a; }
.fps-low  { background:#3a1c1c; color:#ff4b4b; }

/* ── RAM bar ──────────────────────────────────────── */
.ram-bar { border-radius:6px; height:10px; background:#1e2640; overflow:hidden; }
.ram-fill { height:10px; border-radius:6px; background:linear-gradient(90deg,#4f8ef7,#7c3aed); }

/* ── Upgrade tip ──────────────────────────────────── */
.upgrade-tip {
    background:#141926; border-radius:10px; padding:0.8rem 1rem;
    border-left:3px solid #4f8ef7; margin-bottom:0.5rem;
    color:#ccc; font-size:0.88rem;
}

/* ── Prob bar ─────────────────────────────────────── */
.prob-row { display:flex; align-items:center; gap:8px; margin-bottom:5px; }
.prob-bar-bg { flex:1; background:#1e2640; border-radius:6px; height:12px; }
.prob-bar-fill { height:12px; border-radius:6px; }

/* ── Info notice ──────────────────────────────────── */
.info-notice {
    background:#141926; border-radius:10px; padding:0.9rem 1.1rem;
    border:1px solid #2a3860; color:#bbb; font-size:0.84rem;
    line-height:1.6; margin-top:0.5rem;
}

/* ── Divider ──────────────────────────────────────── */
.hw-divider { border:none; border-top:1px solid #1e2640; margin:1.4rem 0; }
</style>
""", unsafe_allow_html=True)

model, scaler = train_model()

st.markdown(
    '<p class="brand-logo">🖥️ Hardware Mind</p>'
    '<p class="brand-sub">PC Hardware Compatibility &amp; Bottleneck Analyser — powered by a Deep ANN</p>',
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown("## 🎯 What are you building?")
    selected_preset = st.radio(
        "Build Goal", list(PRESETS.keys()), index=1, label_visibility="collapsed"
    )
    preset = PRESETS[selected_preset]
    st.markdown(f"""
    <div class="preset-card">
        <h4>{selected_preset}</h4>
        <p>{preset["desc"]}</p>
    </div>""", unsafe_allow_html=True)
    st.divider()

    st.markdown("### 🖥️ Target Resolution")
    res_labels = [r["label"] for r in RESOLUTIONS]
    selected_res_label = st.selectbox("Resolution", res_labels, index=0,
                                      label_visibility="collapsed")
    selected_res = next(r for r in RESOLUTIONS if r["label"] == selected_res_label)
    st.caption("Used to highlight the FPS row and bottleneck severity.")

col_spec, col_result = st.columns([1.4, 1], gap="large")

with col_spec:
    st.markdown('<p class="section-hdr">🔵 Processor (CPU)</p>', unsafe_allow_html=True)
    cpu_name_input = st.text_input("CPU Label (display only)", value=preset["cpu_name"],
                                   placeholder="e.g. Intel Core i7-9700K")
    c1, c2 = st.columns(2)
    with c1:
        cpu_cores = st.slider("Cores",            4, 32,  int(preset["cpu_cores"]),   2)
        cpu_base  = st.slider("Base Clock (GHz)", 2.5, 4.5, float(preset["cpu_base_clock"]),  0.1)
        cpu_tdp   = st.slider("TDP (W)",          65, 280, int(preset["cpu_tdp"]),    5)
    with c2:
        cpu_threads = st.slider("Threads",          4, 64,  int(preset["cpu_threads"]),  2)
        cpu_boost   = st.slider("Boost Clock (GHz)",3.0, 6.0, float(preset["cpu_boost_clock"]), 0.1)

    st.markdown('<p class="section-hdr">🟢 Graphics Card (GPU)</p>', unsafe_allow_html=True)
    gpu_name_input = st.text_input("GPU Label (display only)", value=preset["gpu_name"],
                                   placeholder="e.g. NVIDIA GeForce RTX 4060")
    g1, g2 = st.columns(2)
    with g1:
        gpu_vram   = st.select_slider("VRAM (GB)", [4, 6, 8, 12, 16, 24],
                                      value=int(preset["gpu_vram_gb"]))
        gpu_tflops = st.slider("Compute (TFLOPS)", 5.0, 120.0,
                               float(preset["gpu_tflops"]), 1.0)
    with g2:
        gpu_tdp = st.slider("GPU TDP (W)", 80, 500, int(preset["gpu_tdp"]), 10)

    st.markdown('<p class="section-hdr">💾 RAM & Motherboard</p>', unsafe_allow_html=True)
    r1, r2 = st.columns(2)
    with r1:
        ram_gb   = st.select_slider("RAM (GB)", [8, 16, 32, 64, 128],
                                    value=int(preset["ram_gb"]))
        pcie_ver = st.select_slider("PCIe Version", [3.0, 4.0, 5.0],
                                    value=float(preset["pcie_version"]))
    with r2:
        ram_speed = st.select_slider("RAM Speed (MHz)",
                                     [2400, 3200, 3600, 4800, 6000],
                                     value=int(preset["ram_speed_mhz"]))

    st.markdown('<p class="section-hdr">⚡ Power & Compatibility</p>', unsafe_allow_html=True)
    p1, p2 = st.columns(2)
    with p1:
        psu = st.select_slider("PSU Wattage",
                               [450, 550, 650, 750, 850, 1000, 1200],
                               value=int(preset["psu_wattage"]))
    with p2:
        socket_match  = st.toggle("CPU Socket Match", value=bool(preset["socket_match"]))
        ddr_gen_match = st.toggle("DDR Gen Match",    value=bool(preset["ddr_gen_match"]))

    analyse_btn = st.button("🔍 Analyse My Build", use_container_width=True, type="primary")

config = {
    "cpu_cores":       float(cpu_cores),
    "cpu_threads":     float(cpu_threads),
    "cpu_base_clock":  cpu_base,
    "cpu_boost_clock": cpu_boost,
    "cpu_tdp":         float(cpu_tdp),
    "ram_gb":          float(ram_gb),
    "ram_speed_mhz":   float(ram_speed),
    "gpu_vram_gb":     float(gpu_vram),
    "gpu_tflops":      gpu_tflops,
    "gpu_tdp":         float(gpu_tdp),
    "psu_wattage":     float(psu),
    "pcie_version":    pcie_ver,
    "socket_match":    1.0 if socket_match else 0.0,
    "ddr_gen_match":   1.0 if ddr_gen_match else 0.0,
}

ann_bottleneck, compat_idx, probs = predict(model, scaler, config)
label, color = COMPAT_LABELS[compat_idx]
res_bn_rows  = per_resolution_bottleneck(cpu_cores, cpu_boost, gpu_tflops)
fps_data     = estimate_fps(cpu_cores, cpu_boost, gpu_tflops)
fps_pct_rows = fps_percentages(cpu_cores, cpu_boost, gpu_tflops)
tips         = upgrade_suggestions(ann_bottleneck, cpu_cores, cpu_boost, gpu_tflops)
min_r, rec_r, adv_r, mx_r = recommended_ram(ram_gb)
total_power  = cpu_tdp + gpu_tdp + 100
power_margin = psu - total_power

with col_result:
    st.markdown("### 📊 Analysis Results")

    st.markdown(f"""
    <div>
      <div class="spec-chip">
        <div class="lbl">Processor</div>
        <div class="val">{cpu_name_input}</div>
      </div>
      <div class="spec-chip">
        <div class="lbl">Graphics Card</div>
        <div class="val">{gpu_name_input}</div>
      </div>
      <div class="spec-chip">
        <div class="lbl">Target Resolution</div>
        <div class="val">{selected_res_label}</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<hr class='hw-divider'>", unsafe_allow_html=True)

    ga, gb = st.columns(2)
    with ga:
        gfig = gauge_fig(ann_bottleneck, "ANN Bottleneck")
        st.pyplot(gfig, use_container_width=True)
        plt.close(gfig)
    with gb:
        st.markdown(f"""
        <div class="result-box" style="margin-top:10px;">
          <div class="result-label">Compatibility</div>
          <div class="result-value" style="color:{color};">{label}</div>
        </div>""", unsafe_allow_html=True)

        if power_margin >= 0:
            pwr_icon, pwr_col = "✅", "#21c354"
        else:
            pwr_icon, pwr_col = "🔴", "#ff4b4b"
        st.markdown(f"""
        <div class="result-box">
          <div class="result-label">PSU Budget</div>
          <div class="result-value" style="color:{pwr_col};font-size:1.1rem;">
            {pwr_icon} {psu} W &nbsp;/&nbsp; {total_power:.0f} W needed
          </div>
        </div>""", unsafe_allow_html=True)

    st.markdown("**Compatibility Probabilities**")
    prob_colors = ["#ff4b4b", "#ffa500", "#21c354"]
    for i, (lbl, clr) in COMPAT_LABELS.items():
        pct = probs[i] * 100
        st.markdown(f"""
        <div class="prob-row">
          <span style="width:110px;font-size:0.82rem;color:#ccc;">{lbl}</span>
          <div class="prob-bar-bg">
            <div class="prob-bar-fill" style="width:{pct:.1f}%;background:{prob_colors[i]};"></div>
          </div>
          <span style="width:40px;text-align:right;font-size:0.82rem;color:#fff;">
            {pct:.1f}%
          </span>
        </div>""", unsafe_allow_html=True)

    if not socket_match:
        st.warning("⚠️ CPU socket mismatch — wrong motherboard!")
    if not ddr_gen_match:
        st.warning("⚠️ DDR generation mismatch — check RAM compatibility!")

st.markdown("<hr class='hw-divider'>", unsafe_allow_html=True)
st.markdown("## 🎯 Bottleneck Calculation")

no_bn_res   = [r["Resolution"] for r in res_bn_rows if r["Bottleneck"] < 5.0]
major_bn    = [r for r in res_bn_rows if r["Bottleneck"] >= 5.0]

if no_bn_res:
    st.success(
        f"✅ **No major bottleneck detected at:** {', '.join(no_bn_res)}  \n"
        "Your processor and graphics card work together optimally at these resolutions. "
        "Expect fluid gameplay, high frame rates and flexibility for multitasking."
    )
if major_bn:
    worst = max(major_bn, key=lambda x: x["Bottleneck"])
    limit = worst["Limiting"]
    st.info(
        f"**{limit} bottleneck detected at:** {', '.join(r['Resolution'] for r in major_bn)}  \n"
        f"Most affected: {worst['Resolution']} ({worst['Bottleneck']}%)  \n"
        + ("A GPU bottleneck means your graphics card is fully utilised but frame rates may be "
           "limited at high resolutions or quality settings."
           if limit == "GPU" else
           "A CPU bottleneck means your processor is limiting GPU utilisation. "
           "Consider upgrading your CPU or lowering game threads.")
    )

rows_html = ""
for row in res_bn_rows:
    is_selected = row["Resolution"] == selected_res_label
    bg = "background:#1a2035;" if is_selected else ""
    bn = row["Bottleneck"]
    if bn < 5.0:
        tag = '<span class="tag-none">No bottleneck</span>'
    elif row["Limiting"] == "GPU":
        tag = f'<span class="tag-gpu">Graphics card &nbsp;{bn}%</span>'
    else:
        tag = f'<span class="tag-cpu">Processor &nbsp;{bn}%</span>'
    rows_html += f"""
    <tr style="{bg}">
        <td>{"★ " if is_selected else ""}{row["Resolution"]}</td>
        <td>{bn}%</td>
        <td>{tag}</td>
    </tr>"""

st.markdown(f"""
<table class="hw-table">
  <thead><tr>
    <th>Resolution</th><th>Bottleneck (%)</th><th>Limiting Component</th>
  </tr></thead>
  <tbody>{rows_html}</tbody>
</table>""", unsafe_allow_html=True)

st.markdown("**What can you do?**")
for tip in tips:
    st.markdown(f'<div class="upgrade-tip">{tip}</div>', unsafe_allow_html=True)

st.markdown("<hr class='hw-divider'>", unsafe_allow_html=True)
left_fps, right_ram = st.columns([1.6, 1], gap="large")

with left_fps:
    st.markdown("### 📈 What % of Popular Games Can You Play?")
    st.caption("Results calculated at medium settings across the top 100 most popular games.")
    thresholds = ["30+ FPS", "60+ FPS", "90+ FPS", "120+ FPS", "144+ FPS"]

    fps_header = "".join(f"<th>{t}</th>" for t in thresholds)
    fps_rows_html = ""
    for row in fps_pct_rows:
        is_sel = row["Resolution"] == selected_res_label
        bg = "background:#1a2035;" if is_sel else ""
        cells = ""
        for t in thresholds:
            val = int(row[t].replace("%", ""))
            if val >= 70:
                cls = "fps-hi"
            elif val >= 40:
                cls = "fps-ok"
            else:
                cls = "fps-low"
            cells += f'<td><span class="fps-badge {cls}">{row[t]}</span></td>'
        fps_rows_html += f"<tr style='{bg}'><td>{'★ ' if is_sel else ''}{row['Resolution']}</td>{cells}</tr>"

    st.markdown(f"""
    <table class="hw-table">
      <thead><tr><th>Resolution</th>{fps_header}</tr></thead>
      <tbody>{fps_rows_html}</tbody>
    </table>""", unsafe_allow_html=True)

with right_ram:
    st.markdown("### 💾 Recommended RAM")
    current = ram_gb
    ram_tiers = [
        ("Minimum",        min_r,  "#4f8ef7"),
        ("Recommended",    rec_r,  "#21c354"),
        ("Advanced Users", adv_r,  "#7c3aed"),
        ("Max. Supported", mx_r,   "#ffa500"),
    ]
    for tier_name, tier_val, tier_col in ram_tiers:
        is_cur  = current == tier_val
        pct     = min(tier_val / mx_r * 100, 100)
        sel_str = " ← your build" if is_cur else ""
        st.markdown(f"""
        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;font-size:0.82rem;
                      color:{'#fff' if is_cur else '#aaa'};margin-bottom:3px;">
            <span>{tier_name}{sel_str}</span>
            <span style="color:{tier_col};font-weight:700;">{tier_val} GB</span>
          </div>
          <div class="ram-bar">
            <div class="ram-fill" style="width:{pct}%;background:{tier_col};"></div>
          </div>
        </div>""", unsafe_allow_html=True)

    st.markdown(f"""
    <div class="info-notice">
    💡 <b>Tip:</b> Experiment with resolution to find a better balance.<br>
    Lower resolution → more FPS, less GPU load, exposes CPU limits.<br>
    Higher resolution → more GPU load, lower FPS if GPU is the bottleneck.
    </div>""", unsafe_allow_html=True)

st.markdown("<hr class='hw-divider'>", unsafe_allow_html=True)
st.markdown("## 🎮 Average FPS in Popular Games")
st.caption("Estimated at medium settings. Scaled from real-world reference benchmarks.")

def fps_badge(fps_val):
    if fps_val >= 120: cls = "fps-hi"
    elif fps_val >= 60: cls = "fps-ok"
    else: cls = "fps-low"
    return f'<span class="fps-badge {cls}">{fps_val}</span>'

res_labels = [r["label"] for r in RESOLUTIONS]
res_header  = "".join(
    f'<th style="color:{"#4f8ef7" if r["label"]==selected_res_label else "#4f8ef7"};">'
    f'{"★ " if r["label"]==selected_res_label else ""}{r["label"]}</th>'
    for r in RESOLUTIONS
)
game_rows_html = ""
for g in GAMES:
    cells = "".join(
        f'<td style="{"background:#1a2035;" if r["label"]==selected_res_label else ""}">'
        f'{fps_badge(fps_data[g["name"]][r["label"]])}</td>'
        for r in RESOLUTIONS
    )
    game_rows_html += f'<tr><td>{g["icon"]} {g["name"]}</td>{cells}</tr>'

st.markdown(f"""
<table class="hw-table">
  <thead><tr><th>Game</th>{res_header}</tr></thead>
  <tbody>{game_rows_html}</tbody>
</table>""", unsafe_allow_html=True)

st.markdown("<hr class='hw-divider'>", unsafe_allow_html=True)
with st.expander("📈 Feature Importance — What the ANN focuses on", expanded=False):
    fi_fig = feature_importance_fig(model)
    st.pyplot(fi_fig, use_container_width=True)
    plt.close(fi_fig)
    st.caption(
        "Importance approximated by mean absolute weight magnitude "
        "in the first fully-connected layer of the shared ANN backbone."
    )

from groq import Groq as _Groq

GROQ_API_KEY = "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"

st.markdown("""
<style>
.model-badge {
    display:inline-flex; align-items:center; gap:6px;
    border-radius:8px; padding:5px 14px; font-size:0.82rem;
    font-weight:700; letter-spacing:0.3px; margin-bottom:6px;
}
.badge-groq { background:#1a1f2d; color:#f97316; border:1px solid #7c3a0a; }
.model-panel {
    background:#111827; border-radius:12px; padding:1rem 1.2rem;
    border:1px solid #1e2640; min-height:120px;
}
</style>
""", unsafe_allow_html=True)

st.markdown("<hr class='hw-divider'>", unsafe_allow_html=True)
st.markdown("## 🤖 AI Hardware Advisor")
st.markdown(
    "ultra-fast inference for real-time PC hardware advice."
)

_cfg_ctx = (
    f"Build Goal: {selected_preset}\n"
    f"CPU: {cpu_name_input} — {cpu_cores} cores / {cpu_threads} threads, "
    f"{cpu_base:.1f}–{cpu_boost:.1f} GHz, {cpu_tdp} W TDP\n"
    f"GPU: {gpu_name_input} — {gpu_vram} GB VRAM, {gpu_tflops:.1f} TFLOPS, {gpu_tdp} W TDP\n"
    f"RAM: {ram_gb} GB @ {ram_speed} MHz\n"
    f"PSU: {psu} W | PCIe {pcie_ver} | "
    f"Socket Match: {'Yes' if socket_match else 'No'} | "
    f"DDR Match: {'Yes' if ddr_gen_match else 'No'}\n"
    f"Target Resolution: {selected_res_label}\n"
    f"ANN Predicted Bottleneck: {ann_bottleneck:.1f}%\n"
    f"ANN Predicted Compatibility: {COMPAT_LABELS[compat_idx][0]}\n"
    f"Power Margin: {power_margin:.0f} W {'headroom' if power_margin >= 0 else 'DEFICIT'}"
)

SYSTEM_PROMPT = (
    "You are Hardware Mind, a domain-specific AI assistant specialised exclusively in "
    "PC hardware compatibility, diagnostics, and upgrade advice.\n\n"
    "You have deep expertise in:\n"
    "- CPU and GPU compatibility, bottleneck analysis, and tier matching\n"
    "- Motherboard chipsets, CPU sockets (AM5, LGA1700, LGA1851, TR5, etc.)\n"
    "- RAM: DDR4 vs DDR5, XMP/EXPO profiles, speed and latency trade-offs\n"
    "- GPU architecture, VRAM requirements for different workloads, PCIe bandwidth\n"
    "- PSU sizing, 80+ efficiency ratings, power delivery quality\n"
    "- Thermal design: TDP, cooling solutions, case airflow\n"
    "- Storage: NVMe Gen4/Gen5, SATA SSD, bottlenecks in I/O-heavy tasks\n"
    "- Upgrade paths: when to upgrade CPU vs GPU vs RAM vs PSU\n"
    "- Diagnostics: identifying the bottlenecking component in a real system\n\n"
    f"The user's CURRENT BUILD SPECS and ANN predictions are:\n{_cfg_ctx}\n\n"
    "Always give concrete, actionable advice referencing the user's specs. "
    "Keep answers focused on hardware. Use short paragraphs or bullet points. "
    "Never recommend illegal or unsafe hardware modifications."
)

def call_groq(conversation: list) -> str:
    try:
        client   = _Groq(api_key=GROQ_API_KEY)
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + conversation
        stream   = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=messages,
            temperature=1,
            max_completion_tokens=1024,
            top_p=1,
            stream=True,
            stop=None,
        )
        reply = ""
        for chunk in stream:
            reply += chunk.choices[0].delta.content or ""
        return reply.strip()
    except Exception as exc:
        return f"⚠️ Groq API error: {exc}"

if "llm_messages" not in st.session_state:
    st.session_state.llm_messages = []

STARTERS = [
    "Why is my bottleneck so high?",
    "What GPU upgrade would eliminate my bottleneck?",
    "Is my PSU strong enough for this build?",
    "Should I upgrade my CPU or GPU first?",
    "Is PCIe 3.0 a bottleneck for a high-end GPU?",
    "How much VRAM do I need for 4K gaming?",
    "What RAM speed matters most for gaming?",
    "What CPU cooler do I need for this TDP?",
]

if not st.session_state.llm_messages:
    st.markdown("**💡 Suggested questions — click to ask:**")
    s_cols = st.columns(4)
    for si, sq in enumerate(STARTERS):
        with s_cols[si % 4]:
            if st.button(sq, key=f"starter_{si}", use_container_width=True):
                st.session_state.llm_messages.append({"role": "user", "content": sq})
                st.session_state["_pending_reply"] = True
                st.rerun()

for msg in st.session_state.llm_messages:
    avatar = "🧑‍💻" if msg["role"] == "user" else "🔶"
    with st.chat_message(msg["role"], avatar=avatar):
        st.markdown(msg["content"])

# Generate AI reply for starter-button questions (last message is user, no reply yet)
if st.session_state.get("_pending_reply") and st.session_state.llm_messages:
    st.session_state["_pending_reply"] = False
    with st.chat_message("assistant", avatar="🔶"):
        with st.spinner("🔶 Llama-3.3-70B is thinking…"):
            reply = call_groq(st.session_state.llm_messages)
        st.markdown(reply)
    st.session_state.llm_messages.append({"role": "assistant", "content": reply})

if user_input := st.chat_input("Ask about your build…", key="groq_chat_input"):
    st.session_state.llm_messages.append({"role": "user", "content": user_input})
    with st.chat_message("user", avatar="🧑‍💻"):
        st.markdown(user_input)

    with st.chat_message("assistant", avatar="🔶"):
        with st.spinner("🔶 Llama-3.3-70B is thinking…"):
            reply = call_groq(st.session_state.llm_messages)
        st.markdown(reply)
    st.session_state.llm_messages.append({"role": "assistant", "content": reply})

if st.session_state.llm_messages:
    if st.button("🗑️ Clear conversation", key="clear_chat"):
        st.session_state.llm_messages = []
        st.rerun()

st.markdown("<hr class='hw-divider'>", unsafe_allow_html=True)
with st.expander("📋 Model Info — Llama-3.3-70B-Versatile", expanded=False):
    st.markdown("""
    <div class="model-panel">
      <span class="model-badge badge-groq">🔶 Llama-3.3-70B-Versatile · Groq</span>
      <table style="width:100%;font-size:0.8rem;margin-top:8px;border-collapse:collapse;">
        <tr><td style="color:#888;padding:3px 0;">Developer</td><td style="color:#ddd;">Meta AI</td></tr>
        <tr><td style="color:#888;padding:3px 0;">Parameters</td><td style="color:#ddd;">70 Billion</td></tr>
        <tr><td style="color:#888;padding:3px 0;">Architecture</td><td style="color:#ddd;">Llama 3.3 (GQA, RoPE)</td></tr>
        <tr><td style="color:#888;padding:3px 0;">Context</td><td style="color:#ddd;">128 000 tokens</td></tr>
        <tr><td style="color:#888;padding:3px 0;">Licence</td><td style="color:#ddd;">Llama 3.3 Community</td></tr>
        <tr><td style="color:#888;padding:3px 0;">Inference</td><td style="color:#ddd;">Groq (ultra-fast LPU)</td></tr>
        <tr><td style="color:#888;padding:3px 0;">Strengths</td>
            <td style="color:#f97316;">Superior reasoning, long context, fast streaming</td></tr>
      </table>
    </div>""", unsafe_allow_html=True)

st.markdown("<hr class='hw-divider'>", unsafe_allow_html=True)
st.markdown(
    "<center style='color:#444;font-size:0.78rem;'>"
    "Hardware Mind ANN &nbsp;·&nbsp; "
    "M. Nouman Khalid (2023-BS-AI-133) &nbsp;·&nbsp; Muhammad Saud (2023-BS-AI-153)"
    "<br>LLMs: Meta Llama-3-8B-Instruct &nbsp;·&nbsp; Mistral-7B-Instruct-v0.3 &nbsp;·&nbsp; "
    "Served via Hugging Face Inference API &nbsp;·&nbsp; Inspired by PC-Builds.com"
    "</center>",
    unsafe_allow_html=True,
)